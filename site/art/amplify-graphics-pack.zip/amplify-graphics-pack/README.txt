Amplify graphics pack: UK Parliament Week 2026

Free to use and remix with credit to Amplify (CC BY 4.0). Everything is drawn in code from the portal's six shapes
and four hues, with no photographs. Open any .svg in a web browser to view it, print it (A4, no margins) or save it
as PDF. Fonts are built in.

print/     A4 posters, the sticker sheet, the social card and the ambassador badge
platform/  hero-16x9 (email, Viva Engage, Slack, Bluesky, X), header-3x1 (Teams announcement),
           linkedin-1200x627, portrait-1080x1350 (Instagram, LinkedIn), story-1080x1920 (Stories, TikTok, Reels),
           carousel-1 to carousel-6 (Instagram or LinkedIn carousel, 4:5)

Every QR code opens the live portal. Amplify is independent and unofficial: not a service of the
UK Youth Parliament, NYA or UK Parliament. Contact: use the contact form on the portal.
